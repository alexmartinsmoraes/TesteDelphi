-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: produtos
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tabcategorias`
--

DROP TABLE IF EXISTS `tabcategorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabcategorias` (
  `idCategoria` int NOT NULL,
  `NomeCategoria` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabcategorias`
--

LOCK TABLES `tabcategorias` WRITE;
/*!40000 ALTER TABLE `tabcategorias` DISABLE KEYS */;
INSERT INTO `tabcategorias` VALUES (1,'Automotivo'),(2,'Vestuário'),(3,'Eletrônicos'),(4,'Eletrodomésticos');
/*!40000 ALTER TABLE `tabcategorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabprodutos`
--

DROP TABLE IF EXISTS `tabprodutos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabprodutos` (
  `idprodutos` int NOT NULL,
  `nomeproduto` varchar(45) DEFAULT NULL,
  `nomeReduzido` varchar(45) DEFAULT NULL,
  `dataCadastro` datetime DEFAULT NULL,
  `codigobarras` varchar(15) DEFAULT NULL,
  `codCategoria` int DEFAULT NULL,
  `ValorCusto` float DEFAULT NULL,
  `ValorVenda` float DEFAULT NULL,
  `MargemLucro` float DEFAULT NULL,
  `Unidade` varchar(3) DEFAULT NULL,
  `QtdEstoque` float DEFAULT NULL,
  `QtdEstoqueMin` float DEFAULT NULL,
  `obs` mediumtext,
  PRIMARY KEY (`idprodutos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabprodutos`
--

LOCK TABLES `tabprodutos` WRITE;
/*!40000 ALTER TABLE `tabprodutos` DISABLE KEYS */;
INSERT INTO `tabprodutos` VALUES (0,'dadasdasdads','ewqweqweqwe','2023-10-29 10:55:33','123123123',1,22,22,0,'',22,22,'(MEMO)'),(1,'Freio de veiculo','Freio de veiculo','2024-03-09 00:00:00','7890214563214',1,100,150,50,'PC',100,150,'Não tem'),(2,'Vestido Vermelho','Vestido Vermelho','2024-03-09 00:00:00','7890214563552',2,560,600,45,'UN',80,30,'Não tem'),(3,'Rádio a pilha','Radio a pilha','2024-03-09 00:00:00','78902145635217',3,100,180,60,'UN',50,20,'Não tem'),(4,'wwwwww','wwwwww','2023-10-29 10:55:33','222222222',1,222,222,0,'KG',222,22,'dbmmoOBS\r\n'),(7,'Roupa de linho preta','Roupa de linho preta','2023-10-29 10:55:33','7895452112233',2,300,350,300,'UN',10,10,'(MEMO)');
/*!40000 ALTER TABLE `tabprodutos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `idusuarios` int NOT NULL,
  `nome_usuario` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `usuarioscol` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `perfil` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idusuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (0,'amadeu','123456',NULL,'amadeu@gmail.com','A'),(1,'jose_jose','123',NULL,'joise@gmail.com',''),(2,'amarildo_amarildo','123',NULL,'amarildo@gmail.com','C'),(3,'alex_moraes','123',NULL,'precisainformatica@hotmail.com','U'),(4,'fernado','123',NULL,'fernando@gmail.com','A');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-11  9:27:15
